import { Component, OnInit } from '@angular/core';
import {
  AlertController, ModalController, LoadingController,
  ToastController, NavController
} from '@ionic/angular';
import { AuthProvider } from '../services/auth/auth';
import * as firebase from 'firebase/app';
import { Router, ActivatedRoute } from '@angular/router';
import { Storage } from '@ionic/storage';
import { FirebaseAuthentication } from '@ionic-native/firebase-authentication/ngx';
import { WindowService } from '../window.service';

var window;

@Component({
  selector: 'app-phone-login',
  templateUrl: './phone-login.component.html',
  styleUrls: ['./phone-login.component.scss'],
})
export class PhoneLoginComponent implements OnInit {

  isComplete = false;
  fromFacebook: any;
  phone: any;
  windowRef: any;
  verificationCode: string;
  check = false;
  public recaptchaVerifier:firebase.auth.RecaptchaVerifier;
  constructor(
    private router: Router,
    private win: WindowService,
    private mdl:ModalController,
    private storage: Storage,
    public toastController: ToastController,
    private routerParam: ActivatedRoute) {
  }

  ngOnInit() {
      this.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container');
  }

  async sendcode() {
    const appVerifier = this.recaptchaVerifier;
    const phoneNumberString = "+" + this.phone;
  
    firebase.auth().signInWithPhoneNumber(phoneNumberString, appVerifier)
      .then( confirmationResult => {
       this.check = true;
       confirmationResult.verificationId;

       this.verifyLoginCode(confirmationResult.verificationId,confirmationResult)
    })
    .catch((error) => {
      console.error("SMS not sent", error);
    });
  }

  async verifyLoginCode(id,confirmationResult) {
    this.storage.set('verify', false);
    await this.windowRef.confirmationResult
      .confirm(this.verificationCode)
      .then(result => {
        console.log(result.user);
        this.isComplete = true;
        this.presentToast('تم التحقق من الهاتف بنجاح');
        this.storage.set('verify', true);
      })
      .catch(error => {
        this.storage.set('verify', false);
        console.log(error, "Incorrect code entered?");
        this.presentToast(error);
      });
  }

  async presentToast(message) {
    const toast = await this.toastController.create({
      message,
      duration: 5000
    });
    await toast.present();
  }
  async closeModal(){
    await this.mdl.dismiss();
  }
}