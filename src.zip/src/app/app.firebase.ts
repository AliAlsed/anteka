export const firebaseConfig = {
    apiKey: "AIzaSyA38HugO6cAxuqsbAZ2OppYRylqCoZ2cp8",
    authDomain: "newagent-49a44.firebaseapp.com",
    databaseURL: "https://newagent-49a44.firebaseio.com",
    projectId: "newagent-49a44",
    storageBucket: "newagent-49a44.appspot.com",
    messagingSenderId: "1082400392398",
    appId: "1:1082400392398:web:6bf2aa96331fc1dd"
}
