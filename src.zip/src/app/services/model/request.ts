export interface request {
  sender: string;
  recipient: string;
}
