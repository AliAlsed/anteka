export interface User {
    name: string,  
    image:string,
    phone: string,
    email: string,
    address: string
}